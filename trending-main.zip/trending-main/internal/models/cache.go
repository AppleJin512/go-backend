package models

import "github.com/go-redis/redis/v9"

var Cache *redis.Client

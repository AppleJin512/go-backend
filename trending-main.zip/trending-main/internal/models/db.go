package models

import "github.com/uptrace/bun"

var (
	DB *bun.DB
)

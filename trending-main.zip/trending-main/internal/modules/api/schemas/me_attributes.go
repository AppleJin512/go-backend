package schemas

type MeAttributesRequest struct {
	Collection string `query:"collection"`
}

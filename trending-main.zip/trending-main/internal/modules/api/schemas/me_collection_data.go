package schemas

type MECollectionDataRequest struct {
	Collection string `json:"collection" query:"collection"`
}

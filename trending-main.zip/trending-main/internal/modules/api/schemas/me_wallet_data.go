package schemas

type MEWalletDataRequest struct {
	Wallet string `json:"wallet" query:"wallet"`
}

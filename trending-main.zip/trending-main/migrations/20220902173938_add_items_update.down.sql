ALTER TABLE collections
    DROP COLUMN date_last_items_update;

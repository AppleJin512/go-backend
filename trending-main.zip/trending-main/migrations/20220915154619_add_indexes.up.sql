CREATE INDEX ix_token_mint ON items(token_mint);

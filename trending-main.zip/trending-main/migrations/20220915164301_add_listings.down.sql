DROP TABLE listings;

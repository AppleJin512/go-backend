DROP INDEX uix_symbol_mint_address;

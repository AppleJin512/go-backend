CREATE UNIQUE INDEX uix_symbol_mint_address ON listings(symbol, mint_address);

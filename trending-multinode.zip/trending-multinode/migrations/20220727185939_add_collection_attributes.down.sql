DROP TABLE IF EXISTS attributes;

DROP PROCEDURE IF EXISTS trigger_auto_set_date_fields;

ALTER TABLE activities
    DROP COLUMN name;
ALTER TABLE activities
    DROP COLUMN mint_address;
ALTER TABLE activities
    DROP COLUMN uri;

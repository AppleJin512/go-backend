ALTER TABLE activities
    DROP COLUMN seller;
ALTER TABLE activities
    DROP COLUMN auction_house_address;
ALTER TABLE activities
    DROP COLUMN seller_referral;

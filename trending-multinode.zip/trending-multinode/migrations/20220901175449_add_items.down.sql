DROP TABLE items;

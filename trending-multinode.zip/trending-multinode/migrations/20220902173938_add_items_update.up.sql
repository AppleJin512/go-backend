ALTER TABLE collections
    ADD COLUMN date_last_items_update TIMESTAMP DEFAULT NULL;

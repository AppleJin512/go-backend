DROP INDEX ix_token_mint;

DROP INDEX ix_mint_address;

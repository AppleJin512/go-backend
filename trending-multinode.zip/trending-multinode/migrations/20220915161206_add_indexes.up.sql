CREATE INDEX ix_mint_address ON activities(mint_address);

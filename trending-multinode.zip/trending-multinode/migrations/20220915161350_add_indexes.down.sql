DROP INDEX ix_block_time_desc;

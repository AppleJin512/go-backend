CREATE INDEX ix_block_time_desc ON activities(block_time DESC);
